


<html>
<head>
  <title>Display all records from Database</title>
</head>
<body>

<h2>Client Details</h2>
<link rel="stylesheet" type="text/css" href="bmstyle1.css">

<table width=100% border="2" style="padding-bottom:15px;">
  <tr>
    <td>Id</td>
    <td>Name</td>
    <td>Username</td>
    <td>Address</td>
    <td>Email</td>
	<td>Gender</td>
	<td>Phone no</td>
	<td>Aadhar no</td>
	<td>PAN no</td>
	<td>Account no</td>
	<td>Amount</td>
  </tr>
<?php
session_start();
$username="";
$amount="";
$errors = array();
$dbname = mysqli_connect('localhost', 'root', '', 'registration');

   if (isset($_POST['button'])) {
      
	  $username = mysqli_real_escape_string($dbname, $_POST['username']);
	  $amount = mysqli_real_escape_string($dbname, $_POST['amount']);
      $sql = "SELECT * FROM client where password='$username'";
	  $result = mysqli_query($dbname,$sql);
	  $m=mysqli_query($dbname,$sql);
	 $row = mysqli_fetch_array($m,MYSQLI_ASSOC);
      
      
      $count = mysqli_num_rows($m);
      
      if($count == 1) {
		  $n = "SELECT Amount FROM client WHERE password= '$username'";
      $r = mysqli_query($dbname,$n);
      $row = $r->fetch_assoc();
		   $a=strval($row["Amount"]+$amount);
		  
			$query = "UPDATE client set Amount='$a' WHERE password='$username'";
  	mysqli_query($dbname, $query);
		  
   }
   }
      
   if (isset($_POST['button1'])) {
      
	  $username = mysqli_real_escape_string($dbname, $_POST['username']);
	  $amount = mysqli_real_escape_string($dbname, $_POST['amount']);
		
      $sql = "SELECT * FROM client where password='$username'";
     $result = mysqli_query($dbname,$sql);
	  $m=mysqli_query($dbname,$sql);
	 $row = mysqli_fetch_array($m,MYSQLI_ASSOC);
      
      $count = mysqli_num_rows($m);
      
      if($count == 1) {
		  $n = "SELECT Amount FROM client WHERE password= '$username'";
      $r = mysqli_query($dbname,$n);
      $row = $r->fetch_assoc();
		   $a=strval($row["Amount"]-$amount);
		  if($row["Amount"]-$amount>$amount){
			$query = "UPDATE client set Amount='$a' WHERE password='$username'";
  	mysqli_query($dbname, $query);
		  }
        
   }
   
   }
   if (isset($_POST['button2'])) {
      
	  $username = mysqli_real_escape_string($dbname, $_POST['username']);
	  $amount = mysqli_real_escape_string($dbname, $_POST['amount']);
	  $sql = "SELECT * FROM client where password='$username'";
	$result = mysqli_query($dbname,$sql);
   }
while($data = mysqli_fetch_array($result,MYSQLI_ASSOC))
{
?>
  <tr>
    <td><?php echo $data['id']; ?></td>
    <td><?php echo $data['Name']; ?></td>
    <td><?php echo $data['username']; ?></td>    
    <td><?php echo $data['Address']; ?></td>   
	<td><?php echo $data['email']; ?></td>   
	<td><?php echo $data['Gender']; ?></td>   
	<td><?php echo $data['PhoneNumber']; ?></td>   
	<td><?php echo $data['AadharNumber']; ?></td>   
	<td><?php echo $data['PANNumber']; ?></td>
	<td><?php echo $data['AccountNumber']; ?></td>
<td><?php echo $data['Amount']; ?></td>	
	<td><a href="edit.php?id=<?php echo $data['id']; ?>">Edit</a></td>
    <td><a href="delete2.php?username=<?php echo $data['username']; ?>">Delete</a></td>
  </tr>	
<?php
}
?>

</table >
<p><a href="index3.php" align="left"; style="margin-top:15px; padding:15px; padding-top:15px;">Back</a></p>

</body>
</html>