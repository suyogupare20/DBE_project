<?php

include "server.php"; // Using database connection file here

$username = $_GET['username']; // get id through query string

$del = mysqli_query($db,"delete from client where username = '$username'"); // delete query

if($del)
{
    mysqli_close($db); // Close connection
    header("location:3.php"); // redirects to all records page
	header('location: index3.php');
    exit;	
}
else
{
    echo "Error deleting record"; // display error message if not delete
}

?>