<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: BMS.html');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: clilog.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style1.css">
	<style>
	input[type=text], select {
  width: 20%;
  padding: 12px 20px;
  margin: 8px 100xp;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit]:hover {
  background-color: #45a049;
}



</style>
</head>
<body>

<div class="loggedin">
	<h1>Home Page</h1>
</div>
<div class="container">
  	<!-- notification message -->
  	<?php if (isset($_SESSION['success'])) : ?>
	
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	<p align="right"; style="margin-right:10px; padding:10px;">Welcome <strong><?php echo $_SESSION['name']; ?></strong></p>
		<p align="right"; style="margin-right:20px;"> <a href="index3.php?logout='1'" style="color: red;">logout</a> </p>
		
		
		
		
		
    <form  method="post" action="3.php">
	
    <label for="fname">Password</label>
	<input type="text" id="username" name="username"><br><br>
	<label for="fname">Amount</label>
    <input align="right"; style="margin-right:10px; padding:10px;" type="text" id="amount" name="amount"><br><br>
	<p align="center"; style="margin-right:30px;"> <a href="3.php?logout='1'" style="color: red;"><input type="submit" name="button" value="Deposite"></a> </p>
	<p align="center"; style="margin-right:30px;"> <a href="3.php?logout='1'" style="color: red;"><input type="submit" name="button1" value="Withdeaw"></a> </p>
	<p align="center"; style="margin-right:30px;"> <a href="3.php?logout='1'" style="color: red;"><input type="submit" name="button2" value="Account Detials"></a> </p>
	
	</form>
    <?php endif ?>

		
</body>
</html>